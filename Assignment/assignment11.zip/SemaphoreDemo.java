package com.chaityna.academy.assignment11;

/**
 * Assignment 11: Northern Trust FSD
 * Use of semaphore locks
 */

import java.util.concurrent.*;

public class SemaphoreDemo {


    public static void main(String args[]) throws InterruptedException
    {
        // creating a Semaphore object
        // with number of permits 3
        Semaphore sem = new Semaphore(3);

        ReaderThread mt1 = new ReaderThread(sem, "TA");
        ReaderThread mt2 = new ReaderThread(sem, "TB");
        ReaderThread mt3 = new ReaderThread(sem, "TC");
        ReaderThread mt4 = new ReaderThread(sem, "TD");
        ReaderThread mt5 = new ReaderThread(sem, "TE");

        // stating threads
        mt1.start();
        mt2.start();
        mt3.start();
        mt4.start();
        mt5.start();

        // waiting for threads
        mt1.join();
        mt2.join();
        mt3.join();
        mt4.join();
        mt5.join();

    }
}
//A shared resource/class.
class Shared
{
    static int count = 0;
    static String SHARED_READ_STRING = "Hello I am attending Java Session. What are you doing ?";
    static int wordsRead = 0;
}

class ReaderThread extends Thread
{
    Semaphore sem;
    String threadName;
    public ReaderThread(Semaphore sem, String threadName)
    {
        super(threadName);
        this.sem = sem;
        this.threadName = threadName;
    }

    @Override
    public void run() {
            System.out.println("Starting " + threadName);
            try
            {
                System.out.println(threadName + " is waiting for a permit.");

                // acquiring the lock
                sem.acquire();

                System.out.println(threadName + " gets a permit.");

                String [] words = Shared.SHARED_READ_STRING.split(" ");
                for(int j=0; j < words.length; j++) {
                    if (words.length - 1 >= Shared.wordsRead) {
                        String wordToRead = words[Shared.wordsRead];
                        Shared.wordsRead++;
                        Shared.count--;
                        for (int i = 0; i < wordToRead.length(); i++) {
                            System.out.println(threadName + ": " + wordToRead.toCharArray()[i]);

                            Thread.sleep(500);
                        }
                    }
                }

            } catch (InterruptedException exc) {
                System.out.println(exc);
            }

            // Release the permit.
            System.out.println(threadName + " releases the permit.");
            sem.release();
        }
}


