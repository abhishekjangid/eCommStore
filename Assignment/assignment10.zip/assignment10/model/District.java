package com.fsd.assignment10.model;

public class District implements Area {
    @Override
    public int calculatePopulation() {
        return 0;
    }
}
