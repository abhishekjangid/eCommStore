package com.fsd.assignment10.model;

public class Country implements Area {
    @Override
    public int calculatePopulation() {
        return 0;
    }
}
