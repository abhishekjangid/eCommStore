package com.fsd.assignment10.model;

public interface Area {
    int calculatePopulation();
}
