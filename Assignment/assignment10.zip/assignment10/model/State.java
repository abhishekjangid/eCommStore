package com.fsd.assignment10.model;

public class State implements Area {
    @Override
    public int calculatePopulation() {
        return 0;
    }
}
