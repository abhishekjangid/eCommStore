package com.fsd.assignment10.model;

public class Town implements Area {
    private int population;

    public int getPopulation() {
        return population;
    }

    public void setPopulation(int population) {
        this.population = population;
    }

    @Override
    public int calculatePopulation() {
        return getPopulation();
    }
}
