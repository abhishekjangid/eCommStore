package com.fsd.assignment10;

class Message {
    private String text;

    public Message(String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}

class ChildThread1 implements Runnable {

    private Message message;

    public ChildThread1(Message message) {
        this.message = message;
    }

    @Override
    public void run() {
        String name = Thread.currentThread().getName();
        synchronized (message) {
            try {
                System.out.println("CT1: " + name + " assigned CT2 to do factorial of -> " + message.getText()+" , now waiting....");
                message.wait();
            } catch (InterruptedException exception){
                System.out.println("Exception at CT1 "+exception.getMessage());
            }
            System.out.println("CT1 "+ name +" completed waiting for CT2 with message -> "+message.getText());
        }
    }
}

class ChildThread2 implements Runnable {

    private Message message;

    public ChildThread2(Message message) {
        this.message = message;
    }

    @Override
    public void run() {
        String name = Thread.currentThread().getName();
        synchronized (message){
            try {
                Thread.sleep(5000);
                System.out.println("CT2: "+ name+ " Calculating factorial for -> "+message.getText());
                int result = factorial(Integer.parseInt(message.getText()));
                message.setText("CT2 "+name+" Factorial of "+message.getText()+" is "+result);
                message.notify();
            } catch (InterruptedException exception){
                System.out.println("Exception at CT1 "+exception.getMessage());
            }
            System.out.println("CT2 "+ name +" completed calculating factorial, sent response to CT1");
        }
    }

    private int factorial(int n){
        // not a good code but ok for wait and notify
        return (n == 1 || n == 0) ? 1 : n * factorial(n - 1);
    }
}


public class PartOneThread {

    public static void main(String[] args) throws InterruptedException {
        Message message = new Message("10");
        Thread consumer = new Thread(new ChildThread1(message));
        Thread producer = new Thread(new ChildThread2(message));

        consumer.start();
        producer.start();

        consumer.join();
        producer.join();

    }

}
