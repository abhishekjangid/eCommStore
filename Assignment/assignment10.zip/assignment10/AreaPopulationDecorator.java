package com.fsd.assignment10;

import com.fsd.assignment10.model.Area;

public class AreaPopulationDecorator extends PopulationDecorator{
    public AreaPopulationDecorator(Area decoratedArea) {
        super(decoratedArea);
    }

    @Override
    public int calculatePopulation() {
        return decoratedArea.calculatePopulation();
    }
}
