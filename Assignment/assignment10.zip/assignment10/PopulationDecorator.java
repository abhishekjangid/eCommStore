package com.fsd.assignment10;

import com.fsd.assignment10.model.Area;

public abstract class PopulationDecorator implements Area {
    protected Area decoratedArea;

    public PopulationDecorator(Area decoratedArea){
        this.decoratedArea = decoratedArea;
    }

    public int calculatePopulation(){
        return decoratedArea.calculatePopulation();
    }
}