package com.fsd.assignment10;

import com.fsd.assignment10.model.*;

import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class PartTwoPopulation {
    private static String areaName;

    public static void main(String args[]) {
        Scanner scanner = new Scanner(System.in);
        TreeMap<String, TreeMap> countries;
        TreeMap<String, TreeMap> states;
        TreeMap<String, TreeMap> districts;
        TreeMap<String, Area> towns;

        PartTwoPopulation classObject = new PartTwoPopulation();
        countries = new TreeMap<>();
        do {
            System.out.println("Enter Country Name: ");
            String countryName = scanner.nextLine();
            states = new TreeMap<>();
            do {
                System.out.println("Enter State Name: ");
                String stateName = scanner.nextLine();
                districts = new TreeMap<>();
                do {
                    System.out.println("Enter District Name: ");
                    String districtName = scanner.nextLine();
                    towns = new TreeMap<>();
                    do {
                        System.out.println("Enter town Name: ");
                        String townName = scanner.nextLine();
                        Area townArea = new Town();
                        System.out.println("Enter town population: ");
                        ((Town) townArea).setPopulation(Integer.parseInt(scanner.nextLine()));
                        towns.put(townName, townArea);
                        System.out.println("More towns? (Y/N) : ");
                    } while(scanner.nextLine().equals("Y"));
                    districts.put(districtName, towns);
                    System.out.println("More districts? (Y/N) : ");
                } while(scanner.nextLine().equals("Y"));
                states.put(stateName, districts);
                System.out.println("More states? (Y/N) : ");
            } while(scanner.nextLine().equals("Y"));
            countries.put(countryName, states);
            System.out.println("More countries? (Y/N) : ");
        } while(scanner.nextLine().equals("Y"));

        System.out.println("Which Area Type population you want to view?");
        int population = 0;
        while (true) {
            System.out.println("Enter C, S, D, T, E to exit");
            switch (scanner.nextLine()) {
                case "C":
                case "Country":
                    System.out.println("Calculating Country Population: ");
                    System.out.println("Enter Country name: ");
                    areaName = scanner.nextLine();
                    if (countries.containsKey(areaName)) {
                        TreeMap<String, Country> areas = countries.get(areaName);
                        population = classObject.calculateCountryPopulation(areas);
                    } else {
                        System.out.println("Invalid input. Try again! ");
                    }
                    break;
                case "S":
                case "State":
                    System.out.println("Calculating State Population: ");
                    System.out.println("Enter State name: ");
                    areaName = scanner.nextLine();
                    if (states.containsKey(areaName)) {
                        TreeMap<String, State> areas = states.get(areaName);
                        population = classObject.calculateStatePopulation(areas);
                    } else {
                        System.out.println("Invalid input. Try again! ");
                    }
                    break;
                case "D":
                case "District":
                    System.out.println("Calculating District Population: ");
                    System.out.println("Enter District name: ");
                    areaName = scanner.nextLine();
                    if (districts.containsKey(areaName)) {
                        TreeMap<String, District> areas = districts.get(areaName);
                        population = classObject.calculateDistrictPopulation(areas);
                    } else {
                        System.out.println("Invalid input. Try again! ");
                    }
                    break;
                case "T":
                case "Town":
                    System.out.println("Calculating Town Population: ");
                    System.out.println("Enter town name: ");
                    areaName = scanner.nextLine();
                    if (towns.containsKey(areaName)) {
                        Town area = (Town) towns.get(areaName);
                        population = classObject.calculateTownPopulation(area);
                    } else {
                        System.out.println("Invalid input. Try again! ");
                    }
                    break;
                case "E":
                case "Exit":
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid input. Try again!");
                    break;
            }
            System.out.println("Population -> " + population);
        }
    }

    private int calculateCountryPopulation(TreeMap<String, Country> states) {
        int population = 0;
        Iterator iterator = states.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry entry = (Map.Entry) iterator.next();
            population += calculateStatePopulation((TreeMap<String, State>) entry.getValue());
        }
        return population;
    }

    private int calculateStatePopulation(TreeMap<String, State> districts) {
        int population = 0;
        Iterator iterator = districts.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry entry = (Map.Entry) iterator.next();
            population += calculateDistrictPopulation((TreeMap<String, District>) entry.getValue());
        }
        return population;
    }

    private int calculateDistrictPopulation(TreeMap<String, District> towns) {
        int population = 0;
        Iterator iterator = towns.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry entry = (Map.Entry) iterator.next();
            population += calculateTownPopulation((Town) entry.getValue());
        }
        return population;
    }

    private int calculateTownPopulation(Town area) {
        return new AreaPopulationDecorator(area).calculatePopulation();
    }
}
